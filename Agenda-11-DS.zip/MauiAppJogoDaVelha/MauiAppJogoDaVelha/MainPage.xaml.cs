﻿namespace MauiAppJogoDaVelha
{
    public partial class MainPage : ContentPage
    {
        string vez = "X";
        int jogadas = 0;

        public MainPage()
        {
            InitializeComponent();
        }

        private void Button_Clicked(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            btn.IsEnabled = false;

            if(vez == "X")
            {
                btn.Text = "X";
                vez = "O";
            } 
            else
            {
                btn.Text = "O";
                vez = "X";
            }
            
            jogadas++;
            VerificarVencedor();
        }

        void VerificarVencedor()
        {
            bool ganhou = false;
            string vencedor = "";

            // Linhas
            if (btn10.Text == btn11.Text && btn11.Text == btn12.Text && !string.IsNullOrEmpty(btn10.Text)) { ganhou = true; vencedor = btn10.Text; }
            else if (btn20.Text == btn21.Text && btn21.Text == btn22.Text && !string.IsNullOrEmpty(btn20.Text)) { ganhou = true; vencedor = btn20.Text; }
            else if (btn30.Text == btn31.Text && btn31.Text == btn32.Text && !string.IsNullOrEmpty(btn30.Text)) { ganhou = true; vencedor = btn30.Text; }
            // Colunas
            else if (btn10.Text == btn20.Text && btn20.Text == btn30.Text && !string.IsNullOrEmpty(btn10.Text)) { ganhou = true; vencedor = btn10.Text; }
            else if (btn11.Text == btn21.Text && btn21.Text == btn31.Text && !string.IsNullOrEmpty(btn11.Text)) { ganhou = true; vencedor = btn11.Text; }
            else if (btn12.Text == btn22.Text && btn22.Text == btn32.Text && !string.IsNullOrEmpty(btn12.Text)) { ganhou = true; vencedor = btn12.Text; }
            // Diagonais
            else if (btn10.Text == btn21.Text && btn21.Text == btn32.Text && !string.IsNullOrEmpty(btn10.Text)) { ganhou = true; vencedor = btn10.Text; }
            else if (btn12.Text == btn21.Text && btn21.Text == btn30.Text && !string.IsNullOrEmpty(btn12.Text)) { ganhou = true; vencedor = btn12.Text; }

            if (ganhou)
            {
                DisplayAlert("Fim de Jogo!", $"O {vencedor} ganhou!", "OK");
                Zerar();
            }
            else if (jogadas == 9)
            {
                DisplayAlert("Fim de Jogo!", "Deu Velha!", "OK");
                Zerar();
            }
        }

        void Zerar()
        {
            Button[] botoes = { btn10, btn11, btn12, btn20, btn21, btn22, btn30, btn31, btn32 };
            
            foreach (var btn in botoes)
            {
                btn.Text = "";
                btn.IsEnabled = true;
            }
            
            vez = "X";
            jogadas = 0;
        }
    } 
}